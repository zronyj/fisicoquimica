import os

todo = os.listdir(os.getcwd())
mols = [m for m in todo if '.xyz' in m]

input = """! PM3 Opt\n* xyzfile 0 1 {0}\n"""

for m in mols:
    with open(m[:-4] + '.inp', 'w') as f:
        f.write(input.format(m))
