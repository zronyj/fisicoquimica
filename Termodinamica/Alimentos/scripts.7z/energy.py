import os

todo = os.listdir(os.getcwd())
mols = [m for m in todo if '.out' in m]

energias = {}

for m in mols:
    with open(m, 'r') as f:
        data = f.readlines()
    for d in data:
        if "FINAL SINGLE POINT ENERGY" in d:
            energias[m] = float(d.split(' ')[-1])

with open('ENERGY.csv', 'w') as g:
    llaves = energias.keys()
    g.write("Molecula, E / hartree, E / kJ mol-1\n")
    for e in llaves:
        kjmol = energias[e] * 2625.499
        linea = "{0}, {1:.4f}, {2:.4f}\n".format(e[:-4], energias[e], kjmol)
        g.write(linea)
