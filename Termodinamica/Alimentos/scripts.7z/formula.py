import os

todo = os.listdir(os.getcwd())
mols = [m for m in todo if '.xyz' in m]

input = {}
for m in mols:
    C = 0
    H = 0
    N = 0
    O = 0
    trash = 0
    with open(m, 'r') as f:
        data = f.readlines()
    for d in data[2:]:
        raw = d.split(' ')
        cooked = [t for t in raw if t != '']
        tmp = cooked[0]
        if tmp == 'C':
            C += 1
        elif tmp == 'H':
            H += 1
        elif tmp == 'N':
            N += 1
        elif tmp == 'O':
            O += 1
        else:
            trash += 1
    input[m] = "{0}\tC{1}H{2}N{3}O{4}\n".format(m[:-4], C, H, N, O)

with open('FORMULAS.txt', 'w') as g:
    for k in input.keys():
        g.write(input[k])
